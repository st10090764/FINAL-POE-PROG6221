using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CyberSentinelGUI
{
    public partial class Form1 : Form
    {
        private List<Task> taskList = new List<Task>();
        private List<string> actionLog = new List<string>();
        private object txtTitle;
        private object txtDescription;
        private object txtReminder;

        public object MessageBox { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void btnAddTask_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text.Trim();
            string description = txtDescription.Text.Trim();
            string reminderInput = txtReminder.Text.Trim();

            if (DateTime.TryParse(reminderInput, out DateTime reminder))
            {
                taskList.Add(new Task { Title = title, Description = description, Reminder = reminder });
                actionLog.Add("Task added: {title} (Reminder: {reminder})");

                MessageBox.Show("CyberSentinel: Task added successfully!");
                ClearFields();
            }
            else
            {
                MessageBox.Show("CyberSentinel: Invalid date format. Use YYYY-MM-DD HH:MM.");
            }
        }

        private void btnViewTasks_Click(object sender, EventArgs e, object lstOutput)
        {
            if (taskList.Count == 0)
            {
                MessageBox.Show("CyberSentinel: No tasks yet. Add one first.");
                return;
            }

            lstOutput.Items.Clear();
            lstOutput.Items.Add("CyberSentinel: Your cybersecurity tasks:");

            foreach (var task in taskList)
            {
                lstOutput.Items.Add("---------------------------------------------");
                lstOutput.Items.Add("Title      : {task.Title}");
                lstOutput.Items.Add("Description: {task.Description}");
                lstOutput.Items.Add("Reminder   : {task.Reminder}");
            }

            lstOutput.Items.Add("---------------------------------------------");
        }

        private void btnPasswordHelp_Click(object sender, EventArgs e)
        {
            string tip = "CyberSentinel: A strong password should be at least 12 characters, include numbers, symbols, and both cases.";
            MessageBox.Show(tip);
            actionLog.Add("Displayed password security tip.");
        }

        private void btnPrivacyReminder_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "CyberSentinel: It's good practice to review your privacy settings. Set a reminder?",
                "Privacy Check",
                MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                txtTitle.Text = "Review Privacy Settings";
                txtDescription.Text = "Go through all app and account privacy settings.";
                txtReminder.Text = DateTime.Now.AddDays(7).ToString("yyyy-MM-dd HH:mm");
            }
        }

        private void btnViewHistory_Click(object sender, EventArgs e, object lstOutput)
        {
            lstOutput.Items.Clear();

            if (actionLog.Count == 0)
            {
                lstOutput.Items.Add("CyberSentinel: No actions recorded yet.");
            }
            else
            {
                lstOutput.Items.Add("CyberSentinel: Actions this session:");
                foreach (var log in actionLog)
                {
                    lstOutput.Items.Add("� " + log);
                }
            }
        }

        private void ClearFields()
        {
            txtTitle.Clear();
            txtDescription.Clear();
            txtReminder.Clear();
        }
    }

    internal class MessageBoxButtons
    {
        internal static object YesNo;
    }

    internal class DialogResult
    {
        internal static DialogResult Yes;
    }

    public class Task
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Reminder { get; set; }
    }
}

namespace CyberQuiz
{
    public partial class QuizForm : Form
    {
        private int currentQuestion = 0;
        private int score = 0;

        private List<Question> questions = new List<Question>
        {
            new Question("Phishing is when attackers try to steal your info via fake messages.", new[] {"True", "False"}, 0, true),
            new Question("What's a strong password?", new[] {"123456", "Password123", "fG$9!xRtL@"}, 2),
            new Question("You should use the same password for every site.", new[] {"True", "False"}, 1, true),
            new Question("Which of these is a secure website?", new[] {"http://bank.com", "https://bank.com", "bank.com"}, 1),
            new Question("Clicking unknown links in emails is safe.", new[] {"True", "False"}, 1, true),
            new Question("Two-factor authentication makes accounts safer.", new[] {"True", "False"}, 0),
            new Question("Which password is most secure?", new[] {"dog123", "January2020", "A9@xL!eZ5%"}, 2),
            new Question("You should ignore software updates.", new[] {"True", "False"}, 1, true),
            new Question("What's a good security habit online?", new[] {"Share your login", "Use public Wi-Fi always", "Verify suspicious messages"}, 2),
            new Question("True or False: Pop-ups offering prizes are always legit.", new[] {"True", "False"}, 1, true),
        };

        public QuizForm()
        {
            InitializeComponent();
            LoadQuestion();
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void LoadQuestion(object lblQuestion, object rbOption1, object rbOption2, object rbOption3, object btnNext, object lblFeedback, object MessageBox)
        {
            if (currentQuestion < questions.Count)
            {
                var q = questions[currentQuestion];
                lblQuestion.Text = q.Text;
                rbOption1.Text = q.Options[0];
                rbOption2.Text = q.Options[1];
                rbOption3.Visible = q.Options.Length > 2;
                rbOption3.Text = q.Options.Length > 2 ? q.Options[2] : "";
                btnNext.Enabled = false;
                rbOption1.Checked = rbOption2.Checked = rbOption3.Checked = false;
                lblFeedback.Text = "";
            }
            else
            {
                MessageBox.Show(" Quiz complete! Your score: {score} out of {questions.Count}", "Final Score");
                this.Close();
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e, object MessageBox, object lblFeedback, object btnNext)
        {
            int selected = rbOption1.Checked ? 0 :
                           rbOption2.Checked ? 1 :
                           rbOption3.Checked ? 2 : -1;

            if (selected == -1)
            {
                MessageBox.Show("Please select an option.");
                return;
            }

            var correct = questions[currentQuestion].CorrectIndex;

            if (selected == correct)
            {
                score++;
                lblFeedback.Text = " Correct!";
            }
            else
            {
                lblFeedback.Text = " Incorrect. The correct answer is: {questions[currentQuestion].Options[correct]}";
            }

            btnNext.Enabled = true;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            currentQuestion++;
            LoadQuestion();
        }

        private void LoadQuestion()
        {
            throw new NotImplementedException();
        }
    }

    internal class rbOption3
    {
        internal static bool Checked;
    }

    internal class rbOption2
    {
        internal static bool Checked;
    }

    internal class rbOption1
    {
        internal static bool Checked;
    }

    public class Form
    {
    }

    public class Question
    {
        public string Text;
        public string[] Options;
        public int CorrectIndex;

        public Question(string text, string[] options, int correctIndex, bool isTrueFalse = false)
        {
            Text = text;
            Options = options;
            CorrectIndex = correctIndex;
        }
    }
}

btnSubmit_Click.Click += new EventHandler(btnSubmit_Click);

void btnSubmit_Click(object? sender, EventArgs e)
{
    throw new NotImplementedException();
}

btnNext.Click += new EventHandler(btnNext_Click);

